import speech_recognition as sr



r = sr.Recognizer()

with sr.Microphone() as source:

    print("🎤 speek please ")

    audio = r.listen(source)



try:

    text = r.recognize_google(audio, language="fa-IR")

    print(f"✅ friend you say : {text}")

except:

    print("❌ THERE IS PROBLEM")