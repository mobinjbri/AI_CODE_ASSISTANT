#MOBIN JABBARI
#CS50XURMIA
#AI_CODE_ASSISTANT
# 4/7/2025

#سلام رفیق ! توضیحات مفید و مختصر در کامنت ها داده شده 

import os
import pygame
import sys
import time
import speech_recognition as sr
from pygame import mixer
import openai
from gtts import gTTS
from dotenv import load_dotenv
import threading
import pyttsx3
import tempfile

# Load environment variables
load_dotenv()
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")

# Initialize pygame
pygame.init()
mixer.init()

# Initialize text-to-speech engine
engine = pyttsx3.init()
engine.setProperty('rate', 200)  # Speed of speech


# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("AI Assistant - CS50xUrmia")

# Colors
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
WHITE = (255, 255, 255)

#global variebels
typing_text = ""
typing_index = 0
typing_complete = True
typing_speed = 30 # میلی‌ثانیه بین هر حرف
last_typing_time = 0
current_ai_response = ""

# Fonts
font_large = pygame.font.Font(None, 48)
font_medium = pygame.font.Font(None, 36)
font_small = pygame.font.Font(None, 24)

# Load duck image 

try:
    duck_img = pygame.image.load("duck.jpg")
    duck_img = pygame.transform.scale(duck_img, (200, 200))

except:

    duck_img = None

# AI Assistant states
STATE_WELCOME = 0
STATE_CHAT = 1
current_state = STATE_WELCOME
# Chat variables
chat_messages = []
user_input = ""
listening = False
processing = False

# Initialize OpenAI with OpenRouter
openai.api_base = "https://openrouter.ai/api/v1"
openai.api_key = OPENROUTER_API_KEY



def speak(text):
    global typing_text, typing_index, typing_complete, last_typing_time, current_ai_response
    # ذخیره پاسخ اصلی
    current_ai_response = text
    typing_text = ""
    typing_index = 0
    typing_complete = False
    last_typing_time = pygame.time.get_ticks()

    # تشخیص کد در متن (بین ```)
    if "```" in text:
        # جدا کردن کد از متن معمولی
        parts = text.split("```")
        formatted_text = ""
        for i, part in enumerate(parts):
            if i % 2 == 1:  # بخش کد
                # اضافه کردن تورفتگی برای هر خط کد
                code_lines = part.split('\n')
                indented_code = "\n".join(f"    {line}" for line in code_lines if line.strip())
                formatted_text += f"\n{indented_code}\n"
            else:  # متن معمولی
                formatted_text += part
        text = formatted_text

    # اضافه کردن به تاریخچه چت
    if chat_messages and chat_messages[-1].startswith("AI: "):

        chat_messages[-1] = "AI: " + typing_text

    else:

        chat_messages.append("AI: " + typing_text)

    try:

        # متوقف کردن هر صدای در حال پخش

        engine.stop()

        

        # تنظیم سرعت تایپ متفاوت برای کد و متن معمولی

        code_mode = "```" in current_ai_response

        

        # تایپ متن به صورت حرف به حرف

        for char in text:

            typing_text += char

            if chat_messages and chat_messages[-1].startswith("AI: "):

                chat_messages[-1] = "AI: " + typing_text

            

            # سرعت تایپ کندتر برای کدها

            delay = 30 if code_mode else 20

            pygame.time.delay(delay)

            pygame.display.flip()

        

        typing_complete = True

        

        # پخش صدا پس از نمایش متن

        engine.say(text)

        engine.runAndWait()

        

    except Exception as e:

        print(f"Error in speak function: {str(e)}")

        try:

            tts = gTTS(text=text, lang='en')

            temp_file = os.path.join(tempfile.gettempdir(), "ai_assistant_output.mp3")

            tts.save(temp_file)



            while mixer.music.get_busy():

                pygame.time.Clock().tick(10)



            mixer.music.load(temp_file)

            mixer.music.play()

        except Exception as e2:

            print(f"Fallback speech also failed: {str(e2)}")

    finally:

        # وقتی صدا تمام شد، تایپ را کامل می‌کنیم

        typing_complete = True

        if chat_messages and chat_messages[-1].startswith("AI: "):

            chat_messages[-1] = "AI: " + text

def update_typing_effect():
  global typing_text, typing_index, typing_complete, last_typing_time, current_ai_response

  if not typing_complete and current_ai_response:
     current_time = pygame.time.get_ticks()
     if current_time - last_typing_time > typing_speed:
        if typing_index < len(current_ai_response):
           typing_text += current_ai_response[typing_index]
           typing_index += 1
           last_typing_time = current_time
# به‌روزرسانی آخرین پیام در لیست چت
           if chat_messages and chat_messages[-1].startswith("AI: "):
              chat_messages[-1] = "AI: " + typing_text
           else:
              typing_complete = True

def listen():
    global listening, processing, user_input
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        listening = True
        try:
            audio = r.listen(source, timeout=5, phrase_time_limit=10)
            listening = False
            try:
                user_input = r.recognize_google(audio)
                print("You said:", user_input)
                processing = True
                return user_input
            except sr.UnknownValueError:
                return "Could not understand audio"
            except sr.RequestError:
                return "API unavailable"
        except Exception as e:
            listening = False
            return f"Listening error: {str(e)}"
        

def get_ai_response(prompt):

    """

    Enhanced version with code formatting support

    """

    def is_valid_api_key(api_key):

        return (

            api_key and

            isinstance(api_key, str) and

            api_key.startswith("sk-or-") and

            len(api_key) >= 45

        )



    try:
        if not is_valid_api_key(OPENROUTER_API_KEY):
            return " Invalid API key (correct format: sk-or-xxx)"
        model = "mistralai/mistral-7b-instruct"  # یا مدل دیگری که بهتر کد می‌نویسد
        # دستورالعمل خاص برای تولید کد

        system_message = """You are a helpful AI assistant that provides code snippets.

        Always format code responses with proper line breaks and indentation.

        Do not include any additional explanations unless explicitly asked.

        The code should be ready for copy-paste into an IDE."""

        

        headers = {

            "Authorization": f"Bearer {OPENROUTER_API_KEY}",

            "HTTP-Referer": "https://github.com/mobinjabbari/cs50xurmia",

            "X-Title": "CS50xUrmia AI Assistant"

        }



        response = openai.ChatCompletion.create(

            model=model,

            messages=[

                {"role": "system", "content": system_message},

                {"role": "user", "content": prompt}

            ],

            headers=headers,

            max_tokens=1000,  # افزایش برای کدهای طولانی

            temperature=0.3  # کاهش برای دقت بیشتر

        )



        if not response.choices:

            return "⚠️ Received empty response from server"



        return response.choices[0].message['content']



    except Exception as e:

        return f"⚠️ Error: {str(e)}"
    
def draw_welcome_screen():

    screen.fill(BLACK)

    

    # Draw binary code background

    for i in range(0, WIDTH, 20):

        for j in range(0, HEIGHT, 20):

            text = font_small.render("1" if (i+j) % 3 == 0 else "0", True, (0, 100, 0))

            screen.blit(text, (i, j))

    

    # Draw duck image

    if duck_img:

        screen.blit(duck_img, (WIDTH//2 - 100, HEIGHT//2 - 150))

    

    # Draw welcome text

    welcome_text = font_large.render("Welcome to CS50xUrmia", True, GREEN)
    screen.blit(welcome_text, (WIDTH//2 - welcome_text.get_width()//2, 50))
    creator_text = font_medium.render("I'm the AI assistant created by : Mobin Jabbari", True, WHITE)
    screen.blit(creator_text, (WIDTH//2 - creator_text.get_width()//2, 120))
    instruction_text = font_medium.render("Press F1 to continue", True, RED)
    screen.blit(instruction_text, (WIDTH//2 - instruction_text.get_width()//2, HEIGHT - 100))


def draw_chat_screen():
    screen.fill(BLACK)
    # Draw binary code background
    for i in range(0, WIDTH, 20):

        for j in range(0, HEIGHT, 20):

            text = font_small.render("1" if (i+j) % 3 == 0 else "0", True, (0, 50, 0))

            screen.blit(text, (i, j))
    # Draw chat box
    pygame.draw.rect(screen, (20, 20, 20), (50, 50, WIDTH - 100, HEIGHT - 200), 2)


    # Draw chat messages with word wrapping

    y_offset = 60

    max_line_width = WIDTH - 120  # Maximum width for text before wrapping

    max_lines = 15  # Maximum number of lines to display

    

    for msg in chat_messages[-max_lines:]:  # Show last messages with line limit

        if msg.startswith("You:"):

            color = GREEN

        else:

            color = WHITE

        

        # Split message into words

        words = msg.split(' ')

        lines = []

        current_line = []

        

        # Word wrapping logic

        for word in words:

            test_line = ' '.join(current_line + [word])

            if font_small.size(test_line)[0] <= max_line_width:

                current_line.append(word)

            else:

                lines.append(' '.join(current_line))

                current_line = [word]

        if current_line:

            lines.append(' '.join(current_line))

        

        # Render each line

        for line in lines:

            if y_offset + 30 > HEIGHT - 200:  # Don't go beyond chat box

                break

            text = font_small.render(line, True, color)

            screen.blit(text, (60, y_offset))

            y_offset += 30

    

    # Draw input box

    pygame.draw.rect(screen, WHITE, (50, HEIGHT - 130, WIDTH - 100, 40), 2)

    input_text = font_small.render(user_input, True, WHITE)

    screen.blit(input_text, (60, HEIGHT - 120))

    

    # Draw instructions

    instructions = [

        "F2: Start speaking",

        "F3: Stop listening",

        "F4: Exit"

    ]

    

    for i, instruction in enumerate(instructions):

        text = font_small.render(instruction, True, RED)

        screen.blit(text, (50 + i * 200, HEIGHT - 70))

    

    # Draw status

    status = ""

    if listening:

        status = "Listening..."

    elif processing:

        status = "Processing..."

    else:

        status = "Ready"

    

    status_text = font_small.render(status, True, GREEN)

    screen.blit(status_text, (WIDTH - 150, HEIGHT - 70))

    for i, instruction in enumerate(instructions):

        text = font_small.render(instruction, True, RED)

        screen.blit(text, (50 + i * 200, HEIGHT - 70))

    

    # Draw status

    status = ""

    if listening:

        status = "Listening..."

    elif processing:

        status = "Processing..."

    else:

        status = "Ready"

    

    status_text = font_small.render(status, True, GREEN)

    screen.blit(status_text, (WIDTH - 150, HEIGHT - 70))



def welcome_screen_voice():

    try:

        speak("Welcome to CS50xUrmia")
        speak("I'm the AI assistant created by : Mobin Jabbari")
        time.sleep(0.7)
        speak("Press F1 to continue")

    except Exception as e:

        print(f"Welcome voice error: {str(e)}")



def main():

    global current_state, user_input, chat_messages, listening, processing
    # Play welcome voice
    welcome_thread = threading.Thread(target=welcome_screen_voice)
    welcome_thread.start()
    update_typing_effect()
    running = True

    while running:

        for event in pygame.event.get():

            if event.type == pygame.QUIT:

                running = False

            

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_F1 and current_state == STATE_WELCOME:

                    current_state = STATE_CHAT

                    chat_messages.append("AI: Hello! How can I help you today?")

                    speak("Hello! How can I help you today?")

                

                elif event.key == pygame.K_F2 and current_state == STATE_CHAT and not listening and not processing:
                    def handle_voice_input():
                       global user_input, processing
                       user_input = listen()
                       chat_messages.append(f"You: {user_input}")
                       processing = True
                       response = get_ai_response(user_input)
                       chat_messages.append(f"AI: {response}")
                       speak(response)
                       user_input = ""
                       processing = False
                    listen_thread = threading.Thread(target=lambda: chat_messages.append(f"You: {listen()}"))
                    listen_thread.start()

                

                elif event.key == pygame.K_F3 and current_state == STATE_CHAT and listening:

                    listening = False

                

                elif event.key == pygame.K_F4:

                    speak("Goodbye!")

                    time.sleep(1)

                    running = False

                

                elif event.key == pygame.K_RETURN and current_state == STATE_CHAT and user_input:

                    chat_messages.append(f"You: {user_input}")

                    processing = True

                    response = get_ai_response(user_input)

                    chat_messages.append(f"AI: {response}")

                    speak(response)

                    user_input = ""

                    processing = False

                

                elif event.key == pygame.K_BACKSPACE and current_state == STATE_CHAT:

                    user_input = user_input[:-1]

                

                elif current_state == STATE_CHAT and not listening and not processing and event.unicode.isprintable():

                    user_input += event.unicode

        

        if current_state == STATE_WELCOME:

            draw_welcome_screen()

        elif current_state == STATE_CHAT:

            draw_chat_screen()

        

        pygame.display.flip()

    

    pygame.quit()

    sys.exit()



if __name__ == "__main__":

    main()

